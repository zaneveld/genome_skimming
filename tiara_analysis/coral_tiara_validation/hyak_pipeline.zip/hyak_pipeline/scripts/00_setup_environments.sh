#!/bin/bash
# Run this ONCE from the klone login node (or an interactive compute node).
# Environment creation just resolves/downloads packages -- lightweight, not
# heavy computation -- so the login node is fine for this.
#
#   bash 00_setup_environments.sh

set -euo pipefail

module load conda   # NOT "mamba/latest" -- that module doesn't exist on Klone

# Envs are created under your group's /gscratch space, NOT $HOME/.conda/envs,
# because home directories are capped at 10GB and bioconda environments fill
# that fast. Edit ENV_BASE if your project lives somewhere else.
ENV_BASE=/gscratch/bbiosci/zaneveld_bbio495_2025/kmer_binning_project/ngill2/envs
mkdir -p "${ENV_BASE}"

# Prefer mamba (faster dependency solving) if the conda module provides it;
# otherwise fall back to plain conda -- functionally identical, just slower.
if command -v mamba &> /dev/null; then
    SOLVER=mamba
else
    echo "mamba not found after 'module load conda' -- falling back to conda (slower but works)."
    SOLVER=conda
fi

${SOLVER} create -y --prefix "${ENV_BASE}/iss-env"      -c bioconda -c conda-forge insilicoseq
${SOLVER} create -y --prefix "${ENV_BASE}/assembly-env" -c bioconda -c conda-forge megahit minimap2 samtools seqkit blast pandas
${SOLVER} create -y --prefix "${ENV_BASE}/tiara-env"    -c bioconda -c conda-forge tiara pandas matplotlib scikit-learn
${SOLVER} create -y --prefix "${ENV_BASE}/ncbi-env"     -c conda-forge ncbi-datasets-cli

echo "Done. Activate with, e.g.:"
echo "  module load conda && conda activate ${ENV_BASE}/tiara-env"
